<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- TYPOGRAPHY -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;700&family=Open+Sans:wght@300;400;600;700&display=swap"
        rel="stylesheet">

    <!-- UNIVERSAL STYLESHEET -->
    <link rel="stylesheet" href="./assets/css/style.css">

    <!-- SIGIN CSS -->
    <link rel="stylesheet" href="./assets/css/signin.css">

    <!-- BOOTSTRAP CSS -->
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">

    <!-- FONT ICONS KIT -->
    <script src="https://kit.fontawesome.com/74d240b4ae.js" crossorigin="anonymous"></script>

</head>

<body>
<main>

    <div class="forms">
        <?php
        session_start();
        if(isset($_SESSION['error'])){
            echo "
          <div class='alert alert-danger text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['error']."</p> 
          </div>
        ";
            unset($_SESSION['error']);
        }

        if(isset($_SESSION['success'])){
            echo "
          <div class='alert alert-success text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['success']."</p> 
          </div>
        ";
            unset($_SESSION['success']);
        }
        ?>
        <ul class="tab-group">
            <li class="tab active"><a href="#login">Forgot Password</a></li>
        </ul>
        <form action="reset.php" method="post" id="forgot">
            <div class="input-field">
                <label for="email" class="user">Enter your EmailAddress</label>
                <input type="email" name="email" placeholder="Email" required/>
                <input type="submit" value="Send" name="reset" class="button" />
                <p class="text-p"> <a href="login.php">Login</a> </p>
                <p class="text-p"> <a href="signup.php">Create account</a> </p>
            </div>
        </form>
    </div>

</main>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('.tab a').on('click', function (e) {
            e.preventDefault();

            $(this).parent().addClass('active');
            $(this).parent().siblings().removeClass('active');

            var href = $(this).attr('href');
            $('.forms > form').hide();
            $(href).fadeIn(500);
        });
    });
</script>
</body>

</html>