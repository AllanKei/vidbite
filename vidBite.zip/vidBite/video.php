<?php
session_start();
include "db.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pages</title>
    <link rel="stylesheet" href="./assets/css/sidenav.css">
    <script src="./assets/js/main.js" defer></script>

    <!-- TYPOGRAPHY -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;700&family=Open+Sans:wght@300;400;600;700&display=swap"
        rel="stylesheet">
    <!-- CREATOR PORTAL CSS -->
    <link rel="stylesheet" href="./assets/css/creator_portal.css">


    <!-- FONT ICONS KIT -->
    <script src="https://kit.fontawesome.com/74d240b4ae.js" crossorigin="anonymous"></script>
    <style>
        .wrapper {
            margin-top: 80px !important;
        }
    </style>

</head>

<body>

<header>
    <nav class="navbar">
        <ul class="left-icons">
            <li id="navbtn">
                <i class="fas fa-bars"></i>
            </li>

            <li id="logo">
                <span>VID BITE</span>
            </li>
        </ul>
        <!--
        <div class="search">
            <input type="text" placeholder="Search">
            <span class="searchbtn">
                <i class="fas fa-search"></i>
            </span>
        </div> -->

        <ul class="right-icons">
            <li class="search-icon">
                <i class="fas fa-search"></i>
            </li>

            <li class="create">
                <svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false"
                     class="style-scope yt-icon" style="display: block; width: 100%; height: 100%;">
                    <g class="style-scope yt-icon">
                        <path
                            d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4zM14 13h-3v3H9v-3H6v-2h3V8h2v3h3v2z"
                            class="style-scope yt-icon"></path>
                    </g>
                </svg>
            </li>

            <li class="bell">
                <i class="fas fa-bell"></i>
            </li>

            <li class="bell">
                <a href="" data-toggle="modal" data-target="#logout"><i class="fas fa-power-off"></i></a>

            </li>

            <!-- <li class="profile">
                <img src="./assets/images/profile.jpeg" alt="">
            </li> -->
        </ul>
    </nav>
</header>




<section class="hero">

    <div class="container">

        <div class="wrapper">
            <section class="portal">
                <div class="heading">
                    <h2>
                        Add video
                    </h2>
                </div>
            </section>
        </div>

        <section class="streamManager">
            <?php
            $user=$_SESSION['uid'];
            ?>

            <div class="Srow">
                <!-- Add video-->
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name" class="col-sm-3 control-label" >Video Name</label>

                        <div class="col-sm-5">
                            <input type="hidden" name="id" value="<?php echo $user?>">
                            <input type="text" class="form-control" id="vname" name="vname" required>
                        </div>

                        <label for="category" class="col-sm-3 control-label">Category</label>

                        <div class="col-sm-5">
                            <select class="form-control" id="category" name="category" required>
                                <?php
                                $result=mysqli_query($con,"select * from category")or die ("query 1 incorrect.....");

                                while(list($id,$name)=mysqli_fetch_array($result))
                                {
                                    echo "
                                    <option value='$id'>$name</option>
                                   ";
                                }
                                ?>

                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="video" class="col-sm-1 control-label">Video</label>

                        <div class="col-sm-5">
                            <input type="file" id="video" name="video">
                        </div>
                    </div>
                    <p class="col-sm-3 control-label"><b>Video Info</b></p>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <textarea id="info" name="info" rows="10" cols="80" required></textarea>
                        </div>

                    </div>
                    <input type="submit" name="addvid" value="add">
            </div>

            </div>
        </section>

    </div>




</section>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
<!-- jQuery Modal -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
<script>
    var dd_main = document.querySelector(".dd_main");

    dd_main.addEventListener("click", function () {
        this.classList.toggle("active");
    })
</script>
</body>

</html>

<!-- Logout Modal-->
<div class="modal fade" id="logout" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <form action="action.php" method="post">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary" type="submit" name="logout">Logout</button>
                </form>

            </div>
        </div>
    </div>
</div>