<!-- product details -->

<div class="modal fade" id="product<?php echo $fetch['order_id']?>">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ordered Products(<?php echo $fetch['prod_count']?>)</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <?php
                $order=$fetch['order_id'];
                $sq="SELECT * FROM order_products WHERE order_id = $order ";
                $que = mysqli_query($con, $sq);
                $n=0;
                $n++;
                while($get = mysqli_fetch_array($que)){
                    $proid=$get['product_id'];
                    $result = mysqli_query ( $con, 'select * from products where product_id=' . $proid );
                    $obt = mysqli_fetch_array($result)
                    ?>
                    <h4 class="small font-weight-bold">Product(<?php echo $n++?>): </h4>
                    <img src="../images/<?php echo $obt['photo'] ?>" style="width: 50px;height: 50px;">
                    <p>
                        <?php echo $obt['product_name']; ?><br>
                        Ksh <?php echo $obt['price'] ?><br>
                        <b>Quantity:</b><?php echo $get['quantity'] ?><br>
                        <b>Size:</b><?php echo $get['size'] ?>
                    </p>
                    <hr>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>

<!-- Edit order-->
<div class="modal fade" id="update_order<?php echo $fetch['order_id']?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit order number <?php echo $fetch['order_id']?>? </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>

            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $fetch['order_id']?>">
                    <label for="status" class="col-sm-3 control-label">Status</label>

                    <div class="col-sm-5">
                        <select class="form-control" id="status" name="status" required>
                            <option value="2">confirm</option>
                            <option value='3'>Reject</option>
                        </select>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="editorder"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Delete order -->
<div class="modal fade" id="delete_order<?php echo $fetch['order_id']?>">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete order number <?php echo $fetch['order_id']?>?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Do you want to delete order number <?php echo $fetch ['order_id']?>?</div>
            <div class="modal-footer">
                <form action="action.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $fetch ['order_id']?>">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-danger" type="submit" name="delorder">Delete</button>
                </form>

            </div>
        </div>
    </div>
</div>
