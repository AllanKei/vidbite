<?php
include 'db.php';
include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/navbar.php';
include 'includes/scripts.php';

?>
<div class="container-fluid">
    <h3 class="mt-4 text-gray-600">Dashboard</h3>
</div>
<br>

<div class="row">

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
          <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
              <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                  <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Users</div>
                    <?php
                    $query = "SELECT COUNT(*) AS count_item FROM user";
                    $query_run = mysqli_query($con,$query);
                    $row = mysqli_fetch_array($query_run);
                    $count = $row["count_item"];

                    ?>
                  <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $count?></div>
                </div>
                <div class="col-auto">
                  <i class="fas fa-user fa-2x text-gray-300"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
          <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
              <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                  <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Videos</div>
                    <?php
                    $query = "SELECT COUNT(*) AS count_item FROM videos";
                    $query_run = mysqli_query($con,$query);
                    $row = mysqli_fetch_array($query_run);
                    $count = $row["count_item"];

                    ?>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $count?></div>
                </div>
                <div class="col-auto">
                  <i class="fas fa-user fa-2x text-gray-300"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>