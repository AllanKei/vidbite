<?php
session_start();
include 'db.php';
//add category
if (isset($_POST['addCat'])){
    $name = $_POST['name'];

    $sql = "INSERT INTO category (`cat_id`, `cat_name`) VALUES(NULL,'$name') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Category added successfully';
        header('location:category.php');
    }
    else{
        $_SESSION['error']='Category not added successfully';
        header('location:category.php');
    }
}
//edit category
if (isset($_POST['editcat'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $sql = "UPDATE category SET `cat_name`= '$name' WHERE cat_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Category updated successfully';
        header('location:category.php');
    }
    else{
        $_SESSION['error']='Category not updated successfully';
        header('location:category.php');
    }
}
//delete category
if (isset($_POST['delcat'])){
    $id = $_POST['id'];
    $name = $_POST['name'];

    $sql= "DELETE FROM category WHERE cat_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Category deleted successfully';
        header('location:category.php');
    }
    else{
        $_SESSION['error']='Category not deleted successfully';
        header('location:category.php');
    }
}


//add videos
if (isset($_POST['addVid'])){
    $name = $_POST['name'];
    $category = $_POST['category'];
    $info = $_POST['info'];
    $user =$_POST['user'];
    $date = date('Y-m-d');

    // Get video name
    $video = $_FILES['video']['name'];

    // image file directory
    $target = "../images/".basename($video);

    $sql = "INSERT INTO videos (`vid_id`, `category`,`vid_name`,`info`,`user`,`video`,`date`) VALUES(NULL,'$category','$name','$info','$user','$video','$date') ";
    $query = mysqli_query($con,$sql);

    if (move_uploaded_file($_FILES['video']['tmp_name'], $target)) {
        $_SESSION['success'] = "video uploaded successfully";
        header('location:videos.php');
    }else {
        $_SESSION['error'] = "Failed to upload video";
        header('location:videos.php');
    }
    if ($query){
        $_SESSION['success']='Video added successfully';
        header('location:videos.php');
    }
    else{
        $_SESSION['error']='Video not added successfully';
        header('location:videos.php');
    }
}

//edit video details
if (isset($_POST['editVid'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $category = $_POST['category'];
    $info = $_POST['info'];

    $sql = "UPDATE videos SET `category`= '$category',`vid_name` = '$name',`info` = '$info' WHERE vid_id = '$id' ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Video details updated successfully';
        header('location:videos.php');
    }
    else{
        $_SESSION['error']='Video details not updated';
        header('location:videos.php');
    }
}
//edit video
if (isset($_POST['video'])){
    $id = $_POST['id'];
    // Get video name
    $video = $_FILES['video']['name'];

    // image file directory
    $target = "../images/".basename($video);

    $sql = "UPDATE videos SET `video` = '$video' WHERE vid_id = '$id' ";
    $query = mysqli_query($con,$sql);

    if (move_uploaded_file($_FILES['video']['tmp_name'], $target)) {
        $_SESSION['success'] = "Video uploaded successfully";
        header('location:videos.php');
    }else {
        $_SESSION['error'] = "Failed to upload video";
        header('location:videos.php');
    }

}
//delete product
if (isset($_POST['delvid'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM videos WHERE vid_id = '$id'";
    $query = mysqli_query($con,$sql);
    if ($query){
        $_SESSION['success'] = "Video deleted successfully";
        header('location:videos.php');
    }
    else{
        $_SESSION['error'] = 'Video not deleted';
        header('location:videos.php');
    }
}
//register admin
if (isset($_POST['register'])) {
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($address) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: register.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: signup.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: signup.php');
            exit;
        }

        //existing email address in our database
        $sql = "SELECT id FROM user WHERE email = '$email' LIMIT 1";
        $check_query = mysqli_query($con, $sql);
        $count_email = mysqli_num_rows($check_query);
        if ($count_email > 0) {
            $_SESSION['error'] = 'Email already exists, <a href="login.php">login</a> instead';
            header('location:signup.php');

        } else {

            $sql = "INSERT INTO `user` 
		(`id`, `fname`, `lname`, `email`, 
		`password`,`address`,`contact`,`created_on`) 
		VALUES (NULL, '$first', '$last', '$email', 
		'$password','$address','$contact','$date')";
            $run_query = mysqli_query($con, $sql);
            $_SESSION["uid"] = mysqli_insert_id($con);
            $_SESSION["name"] = $first;

            $ip_add = getenv("REMOTE_ADDR");
            if ($run_query) {

                header('location: login.php');
                exit;
            }
        }
    }
}

//admin login
if (isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM admin WHERE email = '$email'AND password = '$password'";
    $run_query = mysqli_query($con,$sql);
    $count = mysqli_num_rows($run_query);
    $row = mysqli_fetch_array($run_query);
    $_SESSION["uid"] = $row["admin_id"];
    $_SESSION["name"] = $row["uname"];

    if(empty($email) || empty($password)){
        $_SESSION['error'] = 'Fill in the form first';
        header('location:login.php');
    }
    else{
        if ($count == 1){
            header('location: index.php');
        }
        else{
            $_SESSION['error'] = 'Incorrect login credentials';
            header('location:login.php');
        }
    }
}
//logout

if (isset($_POST['logout'])){
    unset($_SESSION['uid']);
    unset($_SESSION['name']);

    header('location:login.php');
}
//edit admin
if (isset($_POST['editadmin'])) {
    $id = $_POST['id'];
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];


    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($address) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: profile.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: profile.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: profile.php');
            exit;
        }
        $sql = "UPDATE admin SET `fname`= '$first',`lname` = '$last',`email` = '$email',`password` = '$password',`address`='$address',`contact`='$contact' WHERE admin_id = '$id' ";
        $run_query = mysqli_query($con, $sql);
        if ($run_query) {
            $_SESSION['success'] = 'Profile updated successfully';
            header('location:profile.php');
        } else {
            $_SESSION['error'] = 'Profile not updated successfully';
            header('location:profile.php');
        }
    }
}

//add user
if (isset($_POST['adduser'])) {
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($address) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: register.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: users.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: users.php');
            exit;
        }

        //existing email address in our database
        $sql = "SELECT user_id FROM users WHERE email = '$email' LIMIT 1";
        $check_query = mysqli_query($con, $sql);
        $count_email = mysqli_num_rows($check_query);
        if ($count_email > 0) {
            $_SESSION['error'] = 'Email already exists';
            header('location:users.php');

        } else {

            $sql = "INSERT INTO `users` 
		(`user_id`, `fname`, `lname`, `email`, 
		`password`,`address`,`contact`,`created_on`) 
		VALUES (NULL, '$first', '$last', '$email', 
		'$password','$address','$contact','$date')";
            $run_query = mysqli_query($con, $sql);

            if ($run_query) {
                $_SESSION['success'] = 'User has been registered successfully';
                header('location:users.php');
            }
            $_SESSION['success'] = 'User has been registered successfully';
            header('location:users.php');
        }
    }
}

// edit user
if (isset($_POST['edituser'])) {
    $id = $_POST['id'];
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($address) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: register.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: users.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: users.php');
            exit;
        }
        else {

            $sql = "UPDATE users SET `fname`= '$first',`lname` = '$last',`email` = '$email',`password` = '$password',`address`='$address',`contact`='$contact' WHERE user_id = '$id' ";

            $run_query = mysqli_query($con, $sql);

            if ($run_query) {
                $_SESSION['success'] = 'User has been updated successfully';
                header('location:users.php');
            }
            else{
                $_SESSION['error'] = 'User has not been updated successfully';
                header('location:users.php');
            }
        }
    }
}
//delete user
if (isset($_POST['deluser'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM users WHERE user_id = '$id'";
    $query = mysqli_query($con,$sql);
    if ($query){
        $_SESSION['success'] = "User deleted successfully";
        header('location:users.php');
    }
    else{
        $_SESSION['error'] = 'User not deleted';
        header('location:users.php');
    }
}

