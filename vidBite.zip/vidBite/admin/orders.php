<?php
include 'db.php';
include 'includes/header.php';
include 'includes/sidebar.php';
include 'includes/navbar.php';
?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="container-fluid">
        <h3 class="mt-4 text-gray-600">Featured orders</h3>
    </div>
    <br>
    <?php

    if(isset($_SESSION['error'])){
        echo "
          <div class='alert alert-danger text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['error']."</p> 
          </div>
        ";
        unset($_SESSION['error']);
    }

    if(isset($_SESSION['success'])){
        echo "
          <div class='alert alert-success text-center'>
          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <p>".$_SESSION['success']."</p> 
          </div>
        ";
        unset($_SESSION['success']);
    }
    ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Orders</h6>
            <button class=" float-right" data-toggle="modal" data-target="#addOrder"><i class="fa fa-plus"></i> Add order</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>OrderNumber</th>
                        <th>CustomerName</th>
                        <th>Contact</th>
                        <th>DelAddress</th>
                        <th>Products</th>
                        <th>Amount</th>
                        <th>Payment</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    $sql = mysqli_query($con, "SELECT *,b.id,b.fname,b.lname,b.contact FROM orders_info,users b WHERE user_id=b.id") or die(mysqli_error());
                    while($fetch = mysqli_fetch_array($sql)){
                        ?>
                        <tr>
                            <td><?php echo $fetch['order_id']?></td>
                            <td>
                                <?php
                                echo $fetch['fname'].' '. $fetch['lname'];
                                ?>
                            </td>
                            <td><?php echo $fetch['contact']?></td>
                            <td><?php echo $fetch['address']?></td>
                            <td>
                                <?php
                                echo $fetch['prod_count'];
                                echo '
                                        <div class="post-category bg-primary mb-3">
                                            <a href="#"  data-toggle="modal" type="button" data-target="#product'.$fetch['order_id'].'" class="text-white" >View</a>
                                        </div>
                                        ';
                                ?>
                            </td>
                            <td><?php echo $fetch['total_amt']?></td>
                            <td><?php echo $fetch['payment']?></td>
                            <td>
                                <?php
                                $status=$fetch['status'];
                                if ($status==1){
                                    echo"
                                        <div class='post-category text-white bg-warning mb-3'>
                                            Pending
                                        </div>
                                        ";
                                }
                                if ($status==2){
                                    echo"
                                        <div class='post-category text-white bg-success mb-3'>
                                            Confirmed 
                                        </div>
                                        ";
                                }
                                if ($status==3){
                                    echo"
                                        <div class='post-category text-white bg-danger mb-3'>
                                            Rejected 
                                        </div>
                                        ";
                                }

                                ?>
                            </td>
                            <td><?php echo $fetch['date']?></td>
                            <td>
                                <a href="#"  data-toggle="modal" type="button" data-target="#update_order<?php echo $fetch['order_id']?>" title="edit"><i class="fas fa-edit fa-lg text-success mr-2"></i></a>
                                <p></p>
                                <a href="#" data-toggle="modal" type="button" data-target="#delete_order<?php echo $fetch['order_id']?>" title="delete"><i class="fas fa-trash-alt fa-lg text-danger"></i></a>
                            </td>

                        </tr>
                        <?php
                        include "editorder.php";
                    }
                    ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
<?php

include 'includes/scripts.php';
include 'includes/modal.php';