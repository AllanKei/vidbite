<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="sidebar border-right" id="sidebar-wrapper">
        <div class="sidebar-heading">Vid Entertainment</div>
        <hr class="sidebar-divider">
        <div class="list-group list-group-flush">
            <a href="index.php" class="list-group-item list-group-item-action text-gray-400">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                Dashboard
            </a>
            <hr>
            <div class="heading">
                <h3 class="text-gray-900">
                    <i class="fas fa-fw fa-cog"></i>
                    components
                </h3>
            </div>
            <hr>
            <a href="users.php" class="list-group-item list-group-item-action text-gray-400">
                <i class="fas fa-user fa-sm fa-fw  "></i>
                Users
            </a>
            <a href="category.php" class="list-group-item list-group-item-action text-gray-400" >
                <i class="fas fa-fw fa-folder "></i>
                Categories
            </a>
            <a href="videos.php" class="list-group-item list-group-item-action text-gray-400" >
                <i class="fas fa-fw fa-folder "></i>
                Videos
            </a>
            <a href="banner.php" class="list-group-item list-group-item-action text-gray-400" >
                <i class="fas fa-fw fa-folder "></i>
                Banner
            </a>
        </div>
    </div>
    <!-- end of sidebar -->