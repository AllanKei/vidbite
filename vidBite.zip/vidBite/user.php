<?php
session_start();
include "db.php";
include "includes/header.php";
include "includes/navbar.php";
?>
<div class="wrapper">
    <section class="portal">
        <?php

        if(isset($_SESSION['error'])){
            echo "
                                              <div class='alert alert-danger text-center'>
                                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                                <p>".$_SESSION['error']."</p> 
                                              </div>
                                            ";
            unset($_SESSION['error']);
        }

        if(isset($_SESSION['success'])){
            echo "
                                              <div class='alert alert-success text-center'>
                                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                                <p>".$_SESSION['success']."</p> 
                                              </div>
                                            ";
            unset($_SESSION['success']);
        }
        ?>
        <div class="heading">
            <h2>
                CREATOR DASHBOARD
            </h2>
        </div>
        <div class="dashContent">
                <div class="box1">
                    <div>
                        <img
                                src="img/user1.png"
                                alt="User profile picture" >
                    </div>
                    <div>
                        <p class="boxLight">
                        <ul class="list">
                            <?php
                            $id=$_GET['id'];
                            $user=$_SESSION['uid'];

                            //existing user like
                            $sq = "SELECT follow_id FROM follow WHERE user = '$user' AND receiver='$id' LIMIT 1";
                            $check_query = mysqli_query($con, $sq);
                            $count_user = mysqli_num_rows($check_query);
                            if ($count_user > 0) {
                                echo '
                            <button class="btn btn-secondary">Following</button>
                            ';
                            }
                            else{
                                echo'
                            <form action="action.php" method="post">
                                <input type="hidden" name="user" value="'.$user.'">
                                <input type="hidden" name="receiver" value="'.$id.'">
                                <button type="submit" name="follow">Follow</button>
                            </form>
                            ';
                            }
                            ?>
                        </ul>
                        </p>
                    </div>

                </div>
                <div class="s_box">
                    <div>
                        <p class="boxBold">
                            Profile Details
                        </p>
                        <p class="boxLight">
                        <ul class="ligh">
                            <?php
                            $sql = "SELECT * FROM user WHERE user_id=$id";
                            $query = mysqli_query($con, $sql);
                            $row = mysqli_fetch_array($query);
                            $first=$row['fname'];
                            $last=$row['lname'];
                            ?>
                            <li><b>Name:<?php echo $first.' ' .$last?></b></li>
                            <li><b>Username:<?php echo $row['uname']?></b></li>
                            <li><b>Email:<?php echo $row['email']?></b></li>
                            <li><b>Member since:<?php echo $row['created_on']?></b></li>
                        </ul>
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <section class="streamManager">
        <div class="heading">
            <h2>
                Videos
            </h2>
        </div>

        <div class="playList">
            <div>
                <div class="boxImg">
                    <img src="./assets/images/./avenger.jpg" alt="">
                </div>
                <div class="details">
                    <div class="profile-pic">
                        <img src="./assets/images/dummy.jpg" alt="">
                    </div>
                    <div class="video-details">
                        <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                        </div>
                        <div class="channel">New Channel</div>
                        <div class="views">
                            <p>17k views </p>
                            <span class="uploaded">2days ago</span>
                        </div>
                        <div class="icon">
                            <a href="">
                                <i class="fas fa-thumbs-up"></i>
                            </a>
                            <a href="">
                                <i class="fas fa-thumbs-down"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="boxImg">
                    <img src="./assets/images/./avenger.jpg" alt="">
                </div>
                <div class="details">
                    <div class="profile-pic">
                        <img src="./assets/images/dummy.jpg" alt="">
                    </div>
                    <div class="video-details">
                        <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                        </div>
                        <div class="channel">New Channel</div>
                        <div class="views">
                            <p>17k views </p>
                            <span class="uploaded">2days ago</span>
                        </div>
                        <div class="icon">
                            <a href="">
                                <i class="fas fa-thumbs-up"></i>
                            </a>
                            <a href="">
                                <i class="fas fa-thumbs-down"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="boxImg">
                    <img src="./assets/images/./avenger.jpg" alt="">
                </div>
                <div class="details">
                    <div class="profile-pic">
                        <img src="./assets/images/dummy.jpg" alt="">
                    </div>
                    <div class="video-details">
                        <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                        </div>
                        <div class="channel">New Channel</div>
                        <div class="views">
                            <p>17k views </p>
                            <span class="uploaded">2days ago</span>
                        </div>
                        <div class="icon">
                            <a href="">
                                <i class="fas fa-thumbs-up"></i>
                            </a>
                            <a href="">
                                <i class="fas fa-thumbs-down"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="boxImg">
                    <img src="./assets/images/./avenger.jpg" alt="">
                </div>
                <div class="details">
                    <div class="profile-pic">
                        <img src="./assets/images/dummy.jpg" alt="">
                    </div>
                    <div class="video-details">
                        <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                        </div>
                        <div class="channel">New Channel</div>
                        <div class="views">
                            <p>17k views </p>
                            <span class="uploaded">2days ago</span>
                        </div>
                        <div class="icon">
                            <a href="">
                                <i class="fas fa-thumbs-up"></i>
                            </a>
                            <a href="">
                                <i class="fas fa-thumbs-down"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
</div>

<?php
include "includes/footer.php";
