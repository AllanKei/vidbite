<?php
session_start();
if (!isset($_SESSION['uid'])){
    header('location:login.php');
}
include "db.php";
include "includes/header.php";
include "includes/navbar.php";
?>

    <!-- carousel slider start here -->

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="item1">
                <!-- <div class="carousel-caption bannerCap d-flex">
                    <div class="capImg">
                        <img src="./assets/images/avenger.jpg" alt="">
                    </div>
                    <div class="capDesc d-flex">
                        <div>
                            <p>
                                Dirty Biology
                            </p>
                            <h6>
                                Lorem ipsum dolor sit amet.
                            </h6>
                        </div>
                    </div>
                </div> -->
            </div>
            <div class="carousel-item" id="item2">
                <!-- <div class="carousel-caption bannerCap d-flex">
                    <div class="capImg">
                        <img src="./assets/images/avenger.jpg" alt="">
                    </div>
                    <div class="capDesc d-flex">
                        <div>
                            <p>
                                Dirty Biology
                            </p>
                            <h6>
                                Lorem ipsum dolor sit amet.
                            </h6>
                        </div>
                    </div>
                </div> -->

            </div>
            <div class="carousel-item" id="item3">
                <!-- <div class="carousel-caption bannerCap d-flex">
                    <div class="capImg">
                        <img src="./assets/images/avenger.jpg" alt="">
                    </div>
                    <div class="capDesc d-flex">
                        <div>
                            <p>
                                Dirty Biology
                            </p>
                            <h6>
                                Lorem ipsum dolor sit amet.
                            </h6>
                        </div>
                    </div>
                </div> -->
            </div>

        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <!-- carousel slider end here -->

    <!-- content section -->
    <section class="wrapper">
        <!-- Logout Modal-->
        <div class="modal fade" id="logout" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <form action="action.php" method="post">
                            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                            <button class="btn btn-primary" type="submit" name="logout">Logout</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>

        <div class="playRow">
            <div class="heading">
                <h2>Recommended For You</h2>
            </div>
            <div class="playList">
                <?php
                    $n=0;
                    $n++;
                    $query = mysqli_query($con, "SELECT * FROM videos") or die(mysqli_error());
                    while($fetch = mysqli_fetch_array($query)){
                        $cat=$fetch['category'];
                        $vid=$fetch['vid_id'];
                ?>
                        <?php
                        echo"
                            <a href=\"view.php?id=$vid\">"
                        ?>

                                <div>

                                    <div class="boxImg">
                                        <video controls width='300px' height='150px'>
                                            <source src="videos/<?php echo $fetch['video']?>">
                                        </video>
                                    </div>
                                    <div class="details">
                                        <div class="profile-pic">
                                            <img src="./assets/images/dummy.jpg" alt="">
                                        </div>
                                        <div class="video-details">
                                            <div class="title">
                                                <?php
                                                echo $fetch['vid_name']
                                                ?>
                                            </div>
                                            <div class="channel">
                                                <?php
                                                $user=$fetch['user'];
                                                $sql="SELECT * FROM user WHERE user_id='$user'";
                                                $que=mysqli_query($con,$sql);
                                                $row=mysqli_fetch_array($que);
                                                $uname=$row['uname'];

                                                echo "
                                            <a href=\"user.php?id=$user\">
                                            $uname Channel
                                            </a>
                                            "
                                                ?>

                                            </div>
                                            <div class="views">
                                                <p>
                                                    <?php
                                                    $qry = "SELECT COUNT(*) AS count_item FROM views WHERE video=$vid";
                                                    $query_run = mysqli_query($con,$qry);
                                                    $wr = mysqli_fetch_array($query_run);
                                                    $count = $wr["count_item"];

                                                    echo ''.$count.' views';
                                                    ?>
                                                </p>
                                                <span class="uploaded"><?php
                                                    $fetch['date']
                                                    ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>

                        <?php
                    }
                        ?>
            </div>

        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Subscription Videos</h2>
            </div>
            <a class="playList subs">
                <?php
                $n=0;
                $n++;
                $query = mysqli_query($con, "SELECT * FROM videos") or die(mysqli_error());
                while($fetch = mysqli_fetch_array($query)){
                    $cat=$fetch['category'];
                    $vid=$fetch['vid_id'];
                    ?>
                    <?php
                    echo"
                            <a href=\"view.php?id=$vid\">"
                    ?>
                    <div>
                        <div class="boxImg">
                            <video controls width='100%' height='150px'>
                                <source src="videos/<?php echo $fetch['video']?>">
                            </video>
                        </div>
                        <div class="details">
                            <div class="profile-pic">
                                <img src="./assets/images/dummy.jpg" alt="">
                            </div>
                            <div class="video-details">
                                <div class="title">
                                    <?php
                                    echo $fetch['vid_name']
                                    ?>
                                </div>
                                <div class="channel">
                                    <?php
                                    $user=$fetch['user'];
                                    $sql="SELECT * FROM user WHERE user_id='$user'";
                                    $que=mysqli_query($con,$sql);
                                    $row=mysqli_fetch_array($que);
                                    $uname=$row['uname'];

                                    echo "
                                            <a href=\"user.php?id=$user\">
                                            $uname Channel
                                            </a>
                                            "
                                    ?>

                                </div>
                                <div class="views">
                                    <p>
                                        <?php
                                        $qry = "SELECT COUNT(*) AS count_item FROM views WHERE video=$vid";
                                        $query_run = mysqli_query($con,$qry);
                                        $wr = mysqli_fetch_array($query_run);
                                        $count = $wr["count_item"];

                                        echo ''.$count.' views';
                                        ?>
                                    </p>
                                    <span class="uploaded"><?php
                                        $fetch['date']
                                        ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    </a>
                    <?php
                }
                ?>
            </div>

        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Continue Watching</h2>
            </div>
            <a class="playList">
                <?php
                $n=0;
                $n++;
                $query = mysqli_query($con, "SELECT * FROM videos") or die(mysqli_error());
                while($fetch = mysqli_fetch_array($query)){
                    $cat=$fetch['category'];
                    $vid=$fetch['vid_id'];
                    ?>
                    <?php
                    echo"
                            <a href=\"view.php?id=$vid\">"
                    ?>
                    <div>
                        <div class="boxImg">
                            <video controls width='100%' height='150px'>
                                <source src="videos/<?php echo $fetch['video']?>">
                            </video>
                        </div>
                        <div class="details">
                            <div class="profile-pic">
                                <img src="./assets/images/dummy.jpg" alt="">
                            </div>
                            <div class="video-details">
                                <div class="title">
                                    <?php
                                    echo $fetch['vid_name']
                                    ?>
                                </div>
                                <div class="channel">
                                    <?php
                                    $user=$fetch['user'];
                                    $sql="SELECT * FROM user WHERE user_id='$user'";
                                    $que=mysqli_query($con,$sql);
                                    $row=mysqli_fetch_array($que);
                                    $uname=$row['uname'];

                                    echo "
                                            <a href=\"user.php?id=$user\">
                                            $uname Channel
                                            </a>
                                            "
                                    ?>
                                    
                                </div>
                                <div class="views">
                                    <p>
                                        <?php
                                        $qry = "SELECT COUNT(*) AS count_item FROM views WHERE video=$vid";
                                        $query_run = mysqli_query($con,$qry);
                                        $wr = mysqli_fetch_array($query_run);
                                        $count = $wr["count_item"];

                                        echo ''.$count.' views';
                                        ?>
                                    </p>
                                    <span class="uploaded"><?php
                                        $fetch['date']
                                        ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>
                    <?php
                }
                ?>
            </div>

        </div>


        <div class="playRow mt-5">
            <div class="heading">
                <h2>Trending</h2>
            </div>
            <a class="playList">
                <?php
                $n=0;
                $n++;
                $query = mysqli_query($con, "SELECT * FROM videos") or die(mysqli_error());
                while($fetch = mysqli_fetch_array($query)){
                    $cat=$fetch['category'];
                    $vid=$fetch['vid_id'];
                    ?>
                    <?php
                    echo"
                            <a href=\"view.php?id=$vid\">"
                    ?>
                    <div>
                        <div class="boxImg">
                            <video controls width='100%' height='150px'>
                                <source src="videos/<?php echo $fetch['video']?>">
                            </video>
                        </div>
                        <div class="details">
                            <div class="profile-pic">
                                <img src="./assets/images/dummy.jpg" alt="">
                            </div>
                            <div class="video-details">
                                <div class="title">
                                    <?php
                                    echo $fetch['vid_name']
                                    ?>
                                </div>
                                <div class="channel">
                                    <?php
                                    $user=$fetch['user'];
                                    $sql="SELECT * FROM user WHERE user_id='$user'";
                                    $que=mysqli_query($con,$sql);
                                    $row=mysqli_fetch_array($que);
                                    $uname=$row['uname'];

                                    echo "
                                            <a href=\"user.php?id=$user\">
                                            $uname Channel
                                            </a>
                                            "
                                    ?>
                                </div>
                                <div class="views">
                                    <p>
                                        <?php
                                        $qry = "SELECT COUNT(*) AS count_item FROM views WHERE video=$vid";
                                        $query_run = mysqli_query($con,$qry);
                                        $wr = mysqli_fetch_array($query_run);
                                        $count = $wr["count_item"];

                                        echo ''.$count.' views';
                                        ?>
                                    </p>
                                    <span class="uploaded"><?php
                                        $fetch['date']
                                        ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>
                    <?php
                }
                ?>
            </div>
        </div>

    </section>

<?php
include "includes/footer.php";
