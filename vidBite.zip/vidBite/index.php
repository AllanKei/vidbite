<?php
session_start();
if (!isset($_SESSION['uid'])){
    header('location:login.php');
}
include "db.php";
include "includes/header.php";
include "includes/navbar.php";
?>

    <!-- carousel slider start here -->

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="item1">
                <!-- <div class="carousel-caption bannerCap d-flex">
                    <div class="capImg">
                        <img src="./assets/images/avenger.jpg" alt="">
                    </div>
                    <div class="capDesc d-flex">
                        <div>
                            <p>
                                Dirty Biology
                            </p>
                            <h6>
                                Lorem ipsum dolor sit amet.
                            </h6>
                        </div>
                    </div>
                </div> -->
            </div>
            <div class="carousel-item" id="item2">
                <!-- <div class="carousel-caption bannerCap d-flex">
                    <div class="capImg">
                        <img src="./assets/images/avenger.jpg" alt="">
                    </div>
                    <div class="capDesc d-flex">
                        <div>
                            <p>
                                Dirty Biology
                            </p>
                            <h6>
                                Lorem ipsum dolor sit amet.
                            </h6>
                        </div>
                    </div>
                </div> -->

            </div>
            <div class="carousel-item" id="item3">
                <!-- <div class="carousel-caption bannerCap d-flex">
                    <div class="capImg">
                        <img src="./assets/images/avenger.jpg" alt="">
                    </div>
                    <div class="capDesc d-flex">
                        <div>
                            <p>
                                Dirty Biology
                            </p>
                            <h6>
                                Lorem ipsum dolor sit amet.
                            </h6>
                        </div>
                    </div>
                </div> -->
            </div>

        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <!-- carousel slider end here -->

    <!-- content section -->
    <section class="wrapper">

        <div class="playRow">
            <div class="heading">
                <h2>Recommended For You</h2>
            </div>
            <div class="playList">
                <?php
                    $n=0;
                    $n++;
                    $query = mysqli_query($con, "SELECT * FROM videos") or die(mysqli_error());
                    while($fetch = mysqli_fetch_array($query)){
                        $cat=$fetch['category'];
                        $vid=$fetch['vid_id'];
                ?>
                        <?php
                        echo"
                            <a href=\"player.php?id=$vid\">"
                        ?>

                                <div>

                                    <div class="boxImg">
                                        <video controls width='300px' height='150px'>
                                            <source src="videos/<?php echo $fetch['video']?>">
                                        </video>
                                    </div>
                                    <div class="details">
                                        <div class="profile-pic">
                                            <img src="./assets/images/dummy.jpg" alt="">
                                        </div>
                                        <div class="video-details">
                                            <div class="title">
                                                <?php
                                                echo $fetch['vid_name']
                                                ?>
                                            </div>
                                            <div class="channel">
                                                <?php
                                                $user=$fetch['user'];
                                                $sql="SELECT * FROM user WHERE user_id='$user'";
                                                $que=mysqli_query($con,$sql);
                                                $row=mysqli_fetch_array($que);
                                                echo $row['uname'];
                                                ?>
                                            </div>
                                            <div class="views">
                                                <p>17k views </p>
                                                <span class="uploaded"><?php
                                                    $fetch['date']
                                                    ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </a>

                        <?php
                    }
                        ?>
                <div>
                    <div class="boxImg">
                        <video controls width='100%' height='150px'>
                            <source src="videos/rally.mp4">
                        </video>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                            <div class="icon">
                                <form action="action.php" method="post">
                                    <a type="submit" name="like">
                                        <i class="fas fa-thumbs-up"></i> 20
                                    </a>
                                    <a type="submit" name="unlike">
                                        <i class="fas fa-thumbs-down"></i> 1
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <video controls width='100%' height='150px'>
                            <source src="videos/rally.mp4">
                        </video>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                            <div class="icon">
                                <form action="action.php" method="post">
                                    <a type="submit" name="like">
                                        <i class="fas fa-thumbs-up"></i> 20
                                    </a>
                                    <a type="submit" name="unlike">
                                        <i class="fas fa-thumbs-down"></i> 1
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Subscription Videos</h2>
            </div>
            <div class="playList subs">
                <?php
                $n=0;
                $n++;
                $query = mysqli_query($con, "SELECT * FROM videos") or die(mysqli_error());
                while($fetch = mysqli_fetch_array($query)){
                    $cat=$fetch['category'];
                    ?>
                    <div>
                        <div class="boxImg">
                            <video controls width='100%' height='150px'>
                                <source src="videos/<?php echo $fetch['video']?>">
                            </video>
                        </div>
                        <div class="details">
                            <div class="profile-pic">
                                <img src="./assets/images/dummy.jpg" alt="">
                            </div>
                            <div class="video-details">
                                <div class="title">
                                    <?php
                                    echo $fetch['vid_name']
                                    ?>
                                </div>
                                <div class="channel">
                                    <?php
                                    $user=$fetch['user'];
                                    $sql="SELECT * FROM user WHERE user_id='$user'";
                                    $que=mysqli_query($con,$sql);
                                    $row=mysqli_fetch_array($que);
                                    echo $row['uname'];
                                    ?>
                                </div>
                                <div class="views">
                                    <p>17k views </p>
                                    <span class="uploaded"><?php
                                        $fetch['date']
                                        ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <div>
                    <div class="boxImg">
                        <video controls width='100%' height='150px'>
                            <source src="videos/rally.mp4">
                        </video>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                            <div class="icon">
                                <form action="action.php" method="post">
                                    <a type="submit" name="like">
                                        <i class="fas fa-thumbs-up"></i> 20
                                    </a>
                                    <a type="submit" name="unlike">
                                        <i class="fas fa-thumbs-down"></i> 1
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <video controls width='100%' height='150px'>
                            <source src="videos/rally.mp4">
                        </video>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                            <div class="icon">
                                <form action="action.php" method="post">
                                    <a type="submit" name="like">
                                        <i class="fas fa-thumbs-up"></i> 20
                                    </a>
                                    <a type="submit" name="unlike">
                                        <i class="fas fa-thumbs-down"></i> 1
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Continue Watching</h2>
            </div>
            <div class="playList">
                <?php
                $n=0;
                $n++;
                $query = mysqli_query($con, "SELECT * FROM videos") or die(mysqli_error());
                while($fetch = mysqli_fetch_array($query)){
                    $cat=$fetch['category'];
                    ?>
                    <div>
                        <div class="boxImg">
                            <video controls width='100%' height='150px'>
                                <source src="videos/<?php echo $fetch['video']?>">
                            </video>
                        </div>
                        <div class="details">
                            <div class="profile-pic">
                                <img src="./assets/images/dummy.jpg" alt="">
                            </div>
                            <div class="video-details">
                                <div class="title">
                                    <?php
                                    echo $fetch['vid_name']
                                    ?>
                                </div>
                                <div class="channel">
                                    <?php
                                    $user=$fetch['user'];
                                    $sql="SELECT * FROM user WHERE user_id='$user'";
                                    $que=mysqli_query($con,$sql);
                                    $row=mysqli_fetch_array($que);
                                    echo $row['uname'];
                                    ?>
                                </div>
                                <div class="views">
                                    <p>17k views </p>
                                    <span class="uploaded"><?php
                                        $fetch['date']
                                        ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <div>
                    <div class="boxImg">
                        <video controls width='100%' height='150px'>
                            <source src="videos/rally.mp4">
                        </video>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                            <div class="icon">
                                <form action="action.php" method="post">
                                    <a type="submit" name="like">
                                        <i class="fas fa-thumbs-up"></i> 20
                                    </a>
                                    <a type="submit" name="unlike">
                                        <i class="fas fa-thumbs-down"></i> 1
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <video controls width='100%' height='150px'>
                            <source src="videos/rally.mp4">
                        </video>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                            <div class="icon">
                                <form action="action.php" method="post">
                                    <a type="submit" name="like">
                                        <i class="fas fa-thumbs-up"></i> 20
                                    </a>
                                    <a type="submit" name="unlike">
                                        <i class="fas fa-thumbs-down"></i> 1
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>


        <div class="playRow mt-5">
            <div class="heading">
                <h2>Trending</h2>
            </div>
            <div class="playList">
                <?php
                $n=0;
                $n++;
                $query = mysqli_query($con, "SELECT * FROM videos") or die(mysqli_error());
                while($fetch = mysqli_fetch_array($query)){
                    $cat=$fetch['category'];
                    ?>
                    <div>
                        <div class="boxImg">
                            <video controls width='100%' height='150px'>
                                <source src="videos/<?php echo $fetch['video']?>">
                            </video>
                        </div>
                        <div class="details">
                            <div class="profile-pic">
                                <img src="./assets/images/dummy.jpg" alt="">
                            </div>
                            <div class="video-details">
                                <div class="title">
                                    <?php
                                    echo $fetch['vid_name']
                                    ?>
                                </div>
                                <div class="channel">
                                    <?php
                                    $user=$fetch['user'];
                                    $sql="SELECT * FROM user WHERE user_id='$user'";
                                    $que=mysqli_query($con,$sql);
                                    $row=mysqli_fetch_array($que);
                                    echo $row['uname'];
                                    ?>
                                </div>
                                <div class="views">
                                    <p>17k views </p>
                                    <span class="uploaded"><?php
                                        $fetch['date']
                                        ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
                <div>
                    <div class="boxImg">
                        <video controls width='100%' height='150px'>
                            <source src="videos/rally.mp4">
                        </video>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                            <div class="icon">
                                <form action="action.php" method="post">
                                    <a type="submit" name="like">
                                        <i class="fas fa-thumbs-up"></i> 20
                                    </a>
                                    <a type="submit" name="unlike">
                                        <i class="fas fa-thumbs-down"></i> 1
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <video controls width='100%' height='150px'>
                            <source src="videos/rally.mp4">
                        </video>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                            <div class="icon">
                                <form action="action.php" method="post">
                                    <a type="submit" name="like">
                                        <i class="fas fa-thumbs-up"></i> 20
                                    </a>
                                    <a type="submit" name="unlike">
                                        <i class="fas fa-thumbs-down"></i> 1
                                    </a>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php
include "includes/footer.php";
