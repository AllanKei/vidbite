<?php
include "includes/header.php";
include "includes/navbar.php";
?>

    <!-- carousel slider start here -->

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active" id="item1">
                <!-- <div class="carousel-caption bannerCap d-flex">
                    <div class="capImg">
                        <img src="./assets/images/avenger.jpg" alt="">
                    </div>
                    <div class="capDesc d-flex">
                        <div>
                            <p>
                                Dirty Biology
                            </p>
                            <h6>
                                Lorem ipsum dolor sit amet.
                            </h6>
                        </div>
                    </div>
                </div> -->
            </div>
            <div class="carousel-item" id="item2">
                <!-- <div class="carousel-caption bannerCap d-flex">
                    <div class="capImg">
                        <img src="./assets/images/avenger.jpg" alt="">
                    </div>
                    <div class="capDesc d-flex">
                        <div>
                            <p>
                                Dirty Biology
                            </p>
                            <h6>
                                Lorem ipsum dolor sit amet.
                            </h6>
                        </div>
                    </div>
                </div> -->

            </div>
            <div class="carousel-item" id="item3">
                <!-- <div class="carousel-caption bannerCap d-flex">
                    <div class="capImg">
                        <img src="./assets/images/avenger.jpg" alt="">
                    </div>
                    <div class="capDesc d-flex">
                        <div>
                            <p>
                                Dirty Biology
                            </p>
                            <h6>
                                Lorem ipsum dolor sit amet.
                            </h6>
                        </div>
                    </div>
                </div> -->
            </div>

        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <!-- carousel slider end here -->

    <!-- content section -->
    <section class="wrapper">

        <div class="playRow">
            <div class="heading">
                <h2>Recommended For You</h2>
            </div>
            <div class="playList">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Subscription Videos</h2>
            </div>
            <div class="playList subs">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Continue Watching</h2>
            </div>
            <div class="playList">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Trending</h2>
            </div>
            <div class="playList">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php
include "includes/footer.php";
