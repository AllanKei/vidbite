<?php

include 'db.php';
    $output = '';
    if(!isset($_GET['code']) OR !isset($_GET['user'])){
		$output .= '
			<div class="alert alert-danger">
                <h6><i class="icon fa fa-warning"></i> Error!</h6>
                Code to activate account not found.
            </div>
            <h6>You may <a href="signup.php">Signup</a> or back to <a href="index.php">Homepage</a>.</h6>
		';
	}
	else{
        $user = $_GET['user'];
        $code = $_GET['code'];

        $query = "SELECT * FROM user WHERE user_id = $user ";
        $run_query = mysqli_query($con,$query);
        $row = mysqli_fetch_array($run_query);
        $active = $row['act_code'];

		if($code=$active){
			if($row['type']== 1){
				$output .= '
					<div class="alert alert-danger">
		                <h6><i class="icon fa fa-warning"></i> Error!</h6>
		                Account already activated.
		            </div>
		            <h6>You may <a href="login.php">Login</a> or back to <a href="index.php">Homepage</a>.</h6>
				';
			}
			else{
                $type=1;
                $sql = "UPDATE user SET type = '$type' WHERE user_id=$user" or die(mysqli_error());
                $query = mysqli_query($con, $sql);
				if($query){

					$output .= '
						<div class="alert alert-success">
			                <h6><i class="icon fa fa-check"></i> Success!</h6>
			                Account activated - Email: <b>'.$row['email'].'</b>.
			            </div>
			            <h6>You may <a href="login.php">Login</a> or back to <a href="index.php">Homepage</a>.</h6>
					';
				}
			}

		}
		else{
			$output .= '
				<div class="alert alert-danger">
	                <h6><i class="icon fa fa-warning"></i> Error!</h6>
	                Cannot activate account. Wrong code.
	            </div>
	            <h6>You may <a href="signup.php">Signup</a> or back to <a href="index.php">Homepage</a>.</h6>
			';
		}
    }

?>
<?php include 'includes/header.php'; ?>

    <div class="signup">
        <div class="container" >
            <div class="row justify-content-center">
                <div class=" col-xl-6">
                    <div class="card-hidden border-0 shadow-lg my-5">
                        <div class="card-body  p-0">
                            <!-- Nested Row within Card Body -->
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="p-5">
                                        <div class="text-center">
                                            <p class=" text-gray-900 mb-4">
                                                <?php echo $output ?>
                                            </p>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>



<?php include 'includes/footer.php'; ?>
