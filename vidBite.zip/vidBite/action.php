<?php
session_start();
//Include required PHPMailer files
require 'phpmailer/includes/PHPMailer.php';
require 'phpmailer/includes/SMTP.php';
require 'phpmailer/includes/Exception.php';

//Define name spaces
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

include 'db.php';
//register user
if (isset($_POST['register'])) {
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $uname=$_POST['uname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $dob = $_POST['dob'];
    $type="1";

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($dob)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: signup.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: signup.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: signup.php');
            exit;
        }

        //existing email address in our database
        $sql = "SELECT user_id FROM user WHERE email = '$email' LIMIT 1";
        $check_query = mysqli_query($con, $sql);
        $count_email = mysqli_num_rows($check_query);
        if ($count_email > 0) {
            $_SESSION['error'] = 'Email already exists, <a href="login.php">login</a> instead';
            header('location:signup.php');
        }
        //existing username in our database
        $sq = "SELECT user_id FROM user WHERE uname = '$uname' LIMIT 1";
        $query_check = mysqli_query($con, $sq);
        $email_count = mysqli_num_rows($query_check);
        if ($email_count > 0) {
            $_SESSION['error'] = 'Username already exists';
            header('location:signup.php');
        }
        else {

            //generate code
            $set = '123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $code = substr(str_shuffle($set), 0, 12);

            $sql = "INSERT INTO `user` 
            (`user_id`, `fname`, `lname`, `email`, 
            `password`,`uname`,`dob`,`act_code`,`reset_code`,`created_on`,`type`) 
            VALUES (NULL, '$first', '$last', '$email', 
            '$password','$uname','$dob','$code','','$date','$type')";

            $run_query = mysqli_query($con, $sql);
            $_SESSION["uid"] = mysqli_insert_id($con);
            $userid = $_SESSION["uid"];
            $_SESSION["name"] = $first;

            $ip_add = getenv("REMOTE_ADDR");
            if ($run_query) {
                $_SESSION['success'] = 'Account created. login.';
                header('location: login.php');
            }else{
                $_SESSION['error'] = 'Account not created';
                header('location: signup.php');

            }
        }
    }

}

//reset password
if (isset($_POST['change'])) {
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $code = $_POST['code'];
    $user = $_POST['user'];

    if (strlen($password) < 8) {
        $_SESSION['error'] = 'Password is weak';
        header('location: password_reset.php' . "?code=$code &user=$user");
        exit;
    }
    if ($password != $repassword) {
        $_SESSION['error'] = 'Passwords dont match';
        header('location: password_reset.php' . "?code=$code &user=$user");
        exit;
    }

    $query = "SELECT * FROM user WHERE user_id = $user ";
    $run_query = mysqli_query($con, $query);
    $row = mysqli_fetch_array($run_query);
    $active = $row['reset_code'];

    if ($code = $active) {
        $sql = "UPDATE user SET password = '$password' WHERE user_id = $user" or die(mysqli_error());
        $query = mysqli_query($con, $sql);
        if ($query) {
            $_SESSION['success'] = 'Password changed successfully.Login now!';
            header('location: login.php');
            exit;
        } else {
            $_SESSION['error'] = 'Passwords not changed successfully';
            header('location: password_reset.php' . "?code=$code &user=$user");
            exit;
        }
    } else {
        $_SESSION['error'] = 'Invalid code.';
        header('location: forgot.php');
        exit;
    }

}
//login action

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM user WHERE email = '$email' AND password = '$password'";
    $run_query = mysqli_query($con, $sql);
    $count = mysqli_num_rows($run_query);
    $row = mysqli_fetch_array($run_query);
    $_SESSION["uid"] = $row["user_id"];
    $_SESSION["name"] = $row["fname"];
    $active = $row["type"];

    if (empty($email) || empty($password)) {
        $_SESSION['error'] = 'Fill in the form first';
        header('location:login.php');
    } else {
        if ($count == 1) {
            if ($active == 1) {
                header('location: index.php');
            } else {
                $_SESSION['error'] = 'Please Activate your account first.';
                header('location:login.php');
            }

        } else {
            $_SESSION['error'] = 'Incorrect login credentials';
            header('location:login.php');
        }
    }

}

//logout

if (isset($_POST['logout'])) {
    unset($_SESSION['uid']);
    unset($_SESSION['name']);

    header('location:login.php');
}



//add videos
if (isset($_POST['addVid'])){
    $video = $_POST['video'];
    $category = $_POST['category'];
    $info = $_POST['info'];
    $user =$_POST['id'];
    $date = date('Y-m-d');

    $maxsize = 100242880; // 5MB

    $name = $_FILES['file']['name'];
    $target_dir = "videos/";
    $target_file = $target_dir . $_FILES["file"]["name"];

    // Select file type
    $extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    // Valid file extensions
    $extensions_arr = array("mp4","avi","3gp","mov","mpeg");

    // Check extension
    if( in_array($extension,$extensions_arr) ){

        // Check file size
        if(($_FILES['file']['size'] >= $maxsize) || ($_FILES["file"]["size"] == 0)) {
            $_SESSION['error'] = "File too large. File must be less than 5MB.";
            header('location:video.php');
        }else{
            // Upload
            if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){
                // Insert record

                $sql = "INSERT INTO videos (`vid_id`, `category`,`vid_name`,`info`,`user`,`video`,`date`) VALUES(NULL,'$category','$video','$info','$user','$name','$date') ";

                $query=mysqli_query($con,$sql);
                if ($query){
                    $_SESSION['success'] = "Upload successfully.";
                    header('location:studio.php');
                }
                else{
                    $_SESSION['error'] = "Upload not successfully.";
                    header('location:studio.php');
                }

            }
        }

    }else{
        $_SESSION['error'] = "Invalid file extension.";
        header('location:video.php');
    }



    if (move_uploaded_file($_FILES['video']['tmp_name'], $target)) {
        $_SESSION['success'] = "video uploaded successfully";
        header('location:profile.php');
    }else {
        $_SESSION['error'] = "Failed to upload video";
        header('location:profile.php');
    }
    if ($query){
        $_SESSION['success']='Video added successfully';
        header('location:profile.php');
    }
    else{
        $_SESSION['error']='Video not added successfully';
        header('location:videos.php');
    }
}

//edit video details
if (isset($_POST['editVid'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $category = $_POST['category'];
    $info = $_POST['info'];

    $sql = "UPDATE videos SET `category`= '$category',`vid_name` = '$name',`info` = '$info' WHERE vid_id = '$id' ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Video details updated successfully';
        header('location:videos.php');
    }
    else{
        $_SESSION['error']='Video details not updated';
        header('location:videos.php');
    }
}
//edit video
if (isset($_POST['video'])){
    $id = $_POST['id'];
    // Get video name
    $video = $_FILES['video']['name'];

    // image file directory
    $target = "../images/".basename($video);

    $sql = "UPDATE videos SET `video` = '$video' WHERE vid_id = '$id' ";
    $query = mysqli_query($con,$sql);

    if (move_uploaded_file($_FILES['video']['tmp_name'], $target)) {
        $_SESSION['success'] = "Video uploaded successfully";
        header('location:videos.php');
    }else {
        $_SESSION['error'] = "Failed to upload video";
        header('location:videos.php');
    }

}
//delete video
if (isset($_POST['delvid'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM videos WHERE vid_id = '$id'";
    $query = mysqli_query($con,$sql);
    if ($query){
        $_SESSION['success'] = "Video deleted successfully";
        header('location:videos.php');
    }
    else{
        $_SESSION['error'] = 'Video not deleted';
        header('location:videos.php');
    }
}
//like
if (isset($_POST['like'])){
    $user=$_POST['user'];
    $video=$_POST['vid'];

    //existing user like
    $sq = "SELECT like_id FROM up WHERE user = '$user' LIMIT 1";
    $check_query = mysqli_query($con, $sq);
    $count_user = mysqli_num_rows($check_query);
    if ($count_user > 0) {
        header('location:player.php'."?id=$video");
        exit();
    }
    $sql = "INSERT INTO up (`like_id`, `user`,`video`) VALUES(NULL,'$user','$video') ";
    $query = mysqli_query($con, $sql);
    if ($query) {
        header('location:player.php' . "?id=$video");
    } else {
        header('location:player.php' . "?id=$video");
    }

}
//unlike
if (isset($_POST['unlike'])){
    $user=$_POST['user'];
    $video=$_POST['vid'];

    //existing user unlike
    $sq = "SELECT dw_id FROM down WHERE user = '$user' LIMIT 1";
    $check_query = mysqli_query($con, $sq);
    $count_user = mysqli_num_rows($check_query);
    if ($count_user > 0) {
        header('location:player.php'."?id=$video");
        exit();
    }

    $sql = "INSERT INTO down (`dw_id`, `user`,`video`) VALUES(NULL,'$user','$video') ";
    $query = mysqli_query($con,$sql);
    if ($query){
        header('location:player.php'."?id=$video");
    }
    else{
        header('location:player.php'."?id=$video");
    }
}
//addmessage
if (isset($_POST['message'])){
    $sender=$_POST['sender'];
    $receiver=$_POST['receiver'];
    $message=$_POST['msg'];
    $now=date('Y-m-d H:i:s');
    $status="0";
    $users=$_POST['users'];

    $sql="INSERT INTO chat (`message_id`,`message_to`,`message_from`,`message`,`timestamp`,`status`,`users`)VALUES(NULL,'$receiver','$sender','$message','$now','$status','$users')";
    $query = mysqli_query($con,$sql);
    if ($query){
        header('location:chat.php'."?id=$users ");
    }
    else{
        header('location:chat.php'."?id=$users ");
    }
}
//delete message


//comments
if (isset($_POST['comm'])){
    $vid=$_POST['video'];
    $user=$_POST['user'];
    $comment=$_POST['comment'];
    $now=date('Y-m-d H:i:s');

    $sql="INSERT INTO comment(`com_id`,`video`,`user`,`message`,`timestamp`)VALUES(NULL,'$vid','$user','$comment','$now')";
    $query = mysqli_query($con,$sql);
    if ($query){
        header('location:player.php'."?id=$vid");
    }
    else{
        header('location:player.php'."?id=$vid");
    }
}
//follow
if (isset($_POST['follow'])){
    $user=$_POST['user'];
    $rec=$_POST['receiver'];

    $sql="INSERT INTO follow(`follow_id`,`user`,`receiver`)VALUES(NULL,'$user','$rec')";
    $query = mysqli_query($con,$sql);
    if ($query){
        header('location:user.php'."?id=$rec");
    }
    else{
        header('location:user.php'."?id=$rec");
    }
}