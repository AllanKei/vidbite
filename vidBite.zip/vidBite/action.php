<?php
session_start();
//Include required PHPMailer files
require 'phpmailer/includes/PHPMailer.php';
require 'phpmailer/includes/SMTP.php';
require 'phpmailer/includes/Exception.php';

//Define name spaces
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

include 'db.php';
//register user
if (isset($_POST['register'])) {
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $uname=$_POST['uname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $dob = $_POST['dob'];
    $type="0";

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($dob)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: signup.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: signup.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: signup.php');
            exit;
        }

        //existing email address in our database
        $sql = "SELECT user_id FROM user WHERE email = '$email' LIMIT 1";
        $check_query = mysqli_query($con, $sql);
        $count_email = mysqli_num_rows($check_query);
        if ($count_email > 0) {
            $_SESSION['error'] = 'Email already exists, <a href="login.php">login</a> instead';
            header('location:signup.php');
        }
        //existing username in our database
        $sq = "SELECT user_id FROM user WHERE uname = '$uname' LIMIT 1";
        $query_check = mysqli_query($con, $sq);
        $email_count = mysqli_num_rows($query_check);
        if ($email_count > 0) {
            $_SESSION['error'] = 'Username already exists';
            header('location:signup.php');
        }
        else {

            //generate code
            $set = '123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $code = substr(str_shuffle($set), 0, 12);

            $sql = "INSERT INTO `user` 
            (`user_id`, `fname`, `lname`, `email`, 
            `password`,`uname`,`dob`,`act_code`,`reset_code`,`created_on`,`type`) 
            VALUES (NULL, '$first', '$last', '$email', 
            '$password','$uname','$dob','$code','','$date','$type')";

            $run_query = mysqli_query($con, $sql);
            $_SESSION["uid"] = mysqli_insert_id($con);
            $userid = $_SESSION["uid"];
            $_SESSION["name"] = $first;

            $ip_add = getenv("REMOTE_ADDR");
            if ($run_query) {

                $message = "
						<h2>Thank you for Registering.</h2>
						<p>Your Account:</p>
						<p>Email: " . $email . "</p>
						<p>Password: " . $_POST['password'] . "</p>
						<p>Please click the link below to activate your account.</p>
						<a href='http://localhost:81/VID_BITE-main/VID_BITE-main/vidBite/activate.php?code=" . $code . "&user=" . $userid . "'>Activate Account</a>
						
                    ";


                //Create instance of PHPMailer
                $mail = new PHPMailer();
                //Set mailer to use smtp
                $mail->isSMTP();
                //Define smtp host
                $mail->Host = "smtp.gmail.com";
                //Enable smtp authentication
                $mail->SMTPAuth = true;
                //Set smtp encryption type (ssl/tls)
                $mail->SMTPSecure = "tls";
                //Port to connect smtp
                $mail->Port = "587";
                //Set gmail username
                $mail->Username = "keiyoh1234@gmail.com";
                //Set gmail password
                $mail->Password = "keiyo2017";
                //Email subject
                $mail->Subject = "ShoeParadise Signup";
                //Set sender email
                $mail->setFrom('keiyoh1234@gmail.com');
                //Enable HTML
                $mail->isHTML(true);
                //Email body
                $mail->Body = $message;
                //Add recipient
                $mail->addAddress($email);
                //Finally send email
                if ($mail->send()) {
                    unset($_SESSION['uid']);
                    unset($_SESSION['name']);
                    $_SESSION['success'] = 'Account created. Check your email to activate.';
                    header('location: signup.php');
                    exit;
                } else {
                    $_SESSION['error'] = 'Message could not be sent. Mailer Error: ' . $mail->ErrorInfo;
                    header('location: signup.php');
                }
                //Closing smtp connection
                $mail->smtpClose();


            }
        }
    }

}

//reset password
if (isset($_POST['change'])) {
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $code = $_POST['code'];
    $user = $_POST['user'];

    if (strlen($password) < 8) {
        $_SESSION['error'] = 'Password is weak';
        header('location: password_reset.php' . "?code=$code &user=$user");
        exit;
    }
    if ($password != $repassword) {
        $_SESSION['error'] = 'Passwords dont match';
        header('location: password_reset.php' . "?code=$code &user=$user");
        exit;
    }

    $query = "SELECT * FROM users WHERE id = $user ";
    $run_query = mysqli_query($con, $query);
    $row = mysqli_fetch_array($run_query);
    $active = $row['reset_code'];

    if ($code = $active) {
        $sql = "UPDATE users SET password = '$password' WHERE id = $user" or die(mysqli_error());
        $query = mysqli_query($con, $sql);
        if ($query) {
            $_SESSION['success'] = 'Password changed successfully.Login now!';
            header('location: login.php');
            exit;
        } else {
            $_SESSION['error'] = 'Passwords not changed successfully';
            header('location: password_reset.php' . "?code=$code &user=$user");
            exit;
        }
    } else {
        $_SESSION['error'] = 'Invalid code.';
        header('location: forgot.php');
        exit;
    }

}
//login action

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $run_query = mysqli_query($con, $sql);
    $count = mysqli_num_rows($run_query);
    $row = mysqli_fetch_array($run_query);
    $_SESSION["uid"] = $row["id"];
    $_SESSION["name"] = $row["fname"];
    $active = $row["type"];

    if (empty($email) || empty($password)) {
        $_SESSION['error'] = 'Fill in the form first';
        header('location:login.php');
    } else {
        if ($count == 1) {
            if ($active == 1) {
                echo 'login_success';
                header('location: index.php');
            } else {
                $_SESSION['error'] = 'Please Activate your account first.';
                header('location:login.php');
            }

        } else {
            $_SESSION['error'] = 'Incorrect login credentials';
            header('location:login.php');
        }
    }

}

//logout

if (isset($_POST['logout'])) {
    unset($_SESSION['uid']);
    unset($_SESSION['name']);

    header('location:index.php');
}