<?php
session_start();
include "db.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pages</title>
    <link rel="stylesheet" href="./assets/css/sidenav.css">
    <script src="./assets/js/main.js" defer></script>

    <!-- TYPOGRAPHY -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link
            href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;700&family=Open+Sans:wght@300;400;600;700&display=swap"
            rel="stylesheet">
    <!-- CREATOR PORTAL CSS -->
    <link rel="stylesheet" href="./assets/css/creator_portal.css">


    <!-- FONT ICONS KIT -->
    <script src="https://kit.fontawesome.com/74d240b4ae.js" crossorigin="anonymous"></script>
    <style>
        .wrapper {
            margin-top: 80px !important;
        }
    </style>

</head>

<body>

<header>
    <nav class="navbar">
        <ul class="left-icons">
            <li id="navbtn">
                <i class="fas fa-bars"></i>
            </li>

            <li id="logo">
                <span>VID BITE</span>
            </li>
        </ul>
        <!--
        <div class="search">
            <input type="text" placeholder="Search">
            <span class="searchbtn">
                <i class="fas fa-search"></i>
            </span>
        </div> -->

        <ul class="right-icons">
            <li class="search-icon">
                <i class="fas fa-search"></i>
            </li>

            <li class="create">
                <a href="video.php">
                    <svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false"
                         class="style-scope yt-icon" style="display: block; width: 100%; height: 100%;">
                        <g class="style-scope yt-icon">
                            <path
                                    d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4zM14 13h-3v3H9v-3H6v-2h3V8h2v3h3v2z"
                                    class="style-scope yt-icon"></path>
                        </g>
                    </svg>
                </a>
            </li>

            <li class="bell">
                <i class="fas fa-bell"></i>
            </li>

            <li class="bell">
                <a href="" data-toggle="modal" data-target="#logout"><i class="fas fa-power-off"></i></a>

            </li>

            <!-- <li class="profile">
                <img src="./assets/images/profile.jpeg" alt="">
            </li> -->
        </ul>
    </nav>
</header>




<section class="hero">
    <div class="sidebar">
        <ul class="left-icons">
            <li id="navbtn_mobile">
                <i class="fas fa-bars"></i>
            </li>

            <li id="logo">
                <span>LOGO</span>
            </li>
        </ul>

        <ul id="sidebar-content">
            <li class="active trigger">
                <i class="fas fa-home"></i>
                <span style="color: #fff;">Home</span>
            </li>

            <li class="trigger">
                <i class="fas fa-satellite-dish"></i>
                <span>Stream Manager</span>
            </li>

            <li class="trigger">
                <i class="fas fa-signal"></i>
                <span>Insights</span>
            </li>

            <li class="trigger">
                <svg viewBox="0 0 24 24" preserveAspectRatio="xMidYMid meet" focusable="false"
                     class="style-scope yt-icon" style="display: block; width: 100%; height: 100%;color: #fff;">
                    <g class="style-scope yt-icon">
                        <path
                                d="M18.7 8.7H5.3V7h13.4v1.7zm-1.7-5H7v1.6h10V3.7zm3.3 8.3v6.7c0 1-.7 1.6-1.6 1.6H5.3c-1 0-1.6-.7-1.6-1.6V12c0-1 .7-1.7 1.6-1.7h13.4c1 0 1.6.8 1.6 1.7zm-5 3.3l-5-2.7V18l5-2.7z"
                                class="style-scope yt-icon"></path>
                    </g>
                </svg>
                <span>
                        Community
                    </span>
            </li>

            <li class="trigger">
                <i class="fas fa-fire"></i>
                <span>Content</span>
            </li>

            <li class="trigger">
                <i class="fas fa-cog"></i>
                <span>Preference</span>
            </li>

            <li class="trigger">
                <svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false"
                     class="style-scope yt-icon" style="display: block; width: 100%; height: 100%;">
                    <g class="style-scope yt-icon">
                        <path
                                d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4zM14 13h-3v3H9v-3H6v-2h3V8h2v3h3v2z"
                                class="style-scope yt-icon"></path>
                    </g>
                </svg>
                <span>Streaming Tools</span>
            </li>

            <li class="trigger">
                <i class="fas fa-puzzle-piece"></i>
                <span>Extensions</span>
            </li>

    </div>

    <div class="container">
        <!-- Modal HTML embedded directly into document -->
        <div id="ex1" class="modal">
            <h4 class="bold">
                Edit Stream Info
            </h4>
            <form action="">
                <div>
                    <label for="">Title</label>
                    <textarea placeholder="Title">

                </textarea>
                </div>
                <div>
                    <label for="">Go Live Notification</label>
                    <textarea placeholder="Go Live Notification">

                </textarea>
                </div>
                <div>
                    <label for="">Category</label>
                    <input placeholder="Category">

                    </input>
                </div>
                <div>
                    <label for="">Tags</label>
                    <input placeholder="Tags">

                    </input>
                </div>
            </form>
            <div class="modalBtn">
                <a href="#" rel="modal:close" class="button Mclose">Close</a>
                <button class="button save">Save</button>
            </div>
        </div>

        <div class="wrapper">
            <section class="portal">
                <?php

                if(isset($_SESSION['error'])){
                    echo "
                                              <div class='alert alert-danger text-center'>
                                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                                <p>".$_SESSION['error']."</p> 
                                              </div>
                                            ";
                    unset($_SESSION['error']);
                }

                if(isset($_SESSION['success'])){
                    echo "
                                              <div class='alert alert-success text-center'>
                                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                                <p>".$_SESSION['success']."</p> 
                                              </div>
                                            ";
                    unset($_SESSION['success']);
                }
                ?>
                <div class="heading">
                    <h2>
                        CREATOR DASHBOARD
                    </h2>
                </div>
                <div class="dashContent">
                    <div class="box1">
                        <div>
                            <img
                                    src="img/1.jpg"
                                    alt="User profile picture">
                        </div>
                        <div>
                            <p class="boxLight">
                            <ul class="list">
                                <li>20<br>
                                    Following
                                </li>
                                <li>30<br>
                                    Followers</li>
                            </ul>
                            </p>
                        </div>
                    </div>
                    <div class="s_box">
                        <div>
                            <p class="boxBold">
                                Profile Details
                            </p>
                            <p class="boxLight">
                            <ul class="ligh">
                                <?php
                                $sql = "SELECT * FROM user WHERE user_id=$_SESSION[uid]";
                                $query = mysqli_query($con, $sql);
                                $row = mysqli_fetch_array($query);
                                $first=$row['fname'];
                                $last=$row['lname'];
                                ?>
                                <li><b>Name:<?php echo $first.' ' .$last?></b></li>
                                <li><b>Username:<?php echo $row['uname']?></b></li>
                                <li><b>Email:<?php echo $row['email']?></b></li>
                                <li><b>Date Joined:<?php echo $row['created_on']?></b></li>
                            </ul>
                            </p>
                        </div>
                        <div class="dashBtn">
                            <button class="button">
                                Edit Profile
                            </button>
                        </div>
                    </div>
                </div>
            </section>
        </div>


        <section class="streamManager">
            <div class="heading">
                <h2>
                    Videos
                </h2>
            </div>

            <div class="playList">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <section class="streamManager">
            <div class="heading">
                <h2>
                    Stream Manager
                </h2>
            </div>

            <div class="Srow">
                <div class="scol1">
                    <div class="stream_head">
                        My Chat
                    </div>
                    <div class="chatContent">
                        <div>
                            <p>
                                Welcome to the chat room!
                            </p>
                        </div>
                        <div>
                            <input type="text" placeholder="Send a message">
                        </div>

                    </div>
                </div>
                <div class="scol2">
                    <div class="stream_head">
                        Stream Preview
                    </div>
                    <div class="videoDiv">
                        <video width="100%" height="100%" poster="" controls>
                            <source src="" type="video/mp4">
                        </video>
                    </div>
                </div>
                <div class="scol3">
                    <div class="stream_head">
                        Quick Actions
                    </div>
                    <div class="quickContent">
                        <div class="card1">
                            <div>
                                <p><a href="#ex1" rel="modal:open">
                                        <i class="fas fa-pencil-alt"></i>
                                    </a></p>

                            </div>
                            <div>
                                <p class="bold">
                                    Edit Stream Info
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

    </div>




</section>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
<!-- jQuery Modal -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
<script>
    var dd_main = document.querySelector(".dd_main");

    dd_main.addEventListener("click", function () {
        this.classList.toggle("active");
    })
</script>
</body>

</html>

<!-- Logout Modal-->
<div class="modal fade" id="logout" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <form action="action.php" method="post">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary" type="submit" name="logout">Logout</button>
                </form>

            </div>
        </div>
    </div>
</div>