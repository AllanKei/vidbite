<?php
session_start();
include "db.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Studio</title>
    <link rel="stylesheet" href="./assets/css/sidenav.css">
    <script src="./assets/js/main.js" defer></script>

    <!-- TYPOGRAPHY -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;700&family=Open+Sans:wght@300;400;600;700&display=swap"
        rel="stylesheet">
    <!-- CREATOR PORTAL CSS -->
    <link rel="stylesheet" href="./assets/css/creator_portal.css">


    <!-- FONT ICONS KIT -->
    <script src="https://kit.fontawesome.com/74d240b4ae.js" crossorigin="anonymous"></script>
    <style>
        .wrapper {
            margin-top: 80px !important;
        }
    </style>

</head>

<body>

<header>
    <nav class="navbar">
        <ul class="left-icons">
            <li id="navbtn">
                <i class="fas fa-bars"></i>
            </li>

            <li id="logo">
                <a href="index.php">
                    <span>VID BITE</span>
                </a>
            </li>
        </ul>
        <!--
        <div class="search">
            <input type="text" placeholder="Search">
            <span class="searchbtn">
                <i class="fas fa-search"></i>
            </span>
        </div> -->

        <ul class="right-icons">
            <li class="search-icon">
                <i class="fas fa-search"></i>
            </li>

            <li class="create">
                <a href="video.php">
                    <svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false"
                         class="style-scope yt-icon" style="display: block; width: 100%; height: 100%;">
                        <g class="style-scope yt-icon">
                            <path
                                d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4zM14 13h-3v3H9v-3H6v-2h3V8h2v3h3v2z"
                                class="style-scope yt-icon"></path>
                        </g>
                    </svg>
                </a>
            </li>

            <li class="bell">
                <i class="fas fa-bell"></i>
            </li>

            <li class="bell">
                <a href="" data-toggle="modal" data-target="#logout"><i class="fas fa-power-off"></i></a>

            </li>

            <!-- <li class="profile">
                <img src="./assets/images/profile.jpeg" alt="">
            </li> -->
        </ul>
    </nav>
</header>




<section class="hero">
    <div class="sidebar">
        <ul class="left-icons">
            <li id="navbtn_mobile">
                <i class="fas fa-bars"></i>
            </li>

            <li id="logo">
                <span>LOGO</span>
            </li>
        </ul>

        <ul id="sidebar-content">
            <li class="active trigger">
                <a href="profile.php">
                    <i class="fas fa-home"></i>
                    <span style="color: #fff;">Home</span>
                </a>

            </li>

            <li class="trigger">
                <i class="fas fa-satellite-dish"></i>
                <span>Stream Manager</span>
            </li>
            <li class="trigger">
                <a href="studio.php">
                    <i class="fas fa-video"></i>
                    <span>Studio</span>
                </a>

            </li>
            <li class="trigger">
                <i class="fas fa-signal"></i>
                <span>Insights</span>
            </li>

            <li class="trigger">
                <svg viewBox="0 0 24 24" preserveAspectRatio="xMidYMid meet" focusable="false"
                     class="style-scope yt-icon" style="display: block; width: 100%; height: 100%;color: #fff;">
                    <g class="style-scope yt-icon">
                        <path
                            d="M18.7 8.7H5.3V7h13.4v1.7zm-1.7-5H7v1.6h10V3.7zm3.3 8.3v6.7c0 1-.7 1.6-1.6 1.6H5.3c-1 0-1.6-.7-1.6-1.6V12c0-1 .7-1.7 1.6-1.7h13.4c1 0 1.6.8 1.6 1.7zm-5 3.3l-5-2.7V18l5-2.7z"
                            class="style-scope yt-icon"></path>
                    </g>
                </svg>
                <span>
                        Community
                    </span>
            </li>

            <li class="trigger">
                <i class="fas fa-fire"></i>
                <span>Content</span>
            </li>

            <li class="trigger">
                <i class="fas fa-cog"></i>
                <span>Preference</span>
            </li>

            <li class="trigger">
                <svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false"
                     class="style-scope yt-icon" style="display: block; width: 100%; height: 100%;">
                    <g class="style-scope yt-icon">
                        <path
                            d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4zM14 13h-3v3H9v-3H6v-2h3V8h2v3h3v2z"
                            class="style-scope yt-icon"></path>
                    </g>
                </svg>
                <span>Streaming Tools</span>
            </li>

            <li class="trigger">
                <i class="fas fa-puzzle-piece"></i>
                <span>Extensions</span>
            </li>

    </div><div class="sidebar">
        <ul class="left-icons">
            <li id="navbtn_mobile">
                <i class="fas fa-bars"></i>
            </li>

            <li id="logo">
                <span>LOGO</span>
            </li>
        </ul>

        <ul id="sidebar-content">
            <li class="active trigger">
                <a href="profile.php">
                    <i class="fas fa-home"></i>
                    <span style="color: #fff;">Home</span>
                </a>

            </li>

            <li class="trigger">
                <i class="fas fa-satellite-dish"></i>
                <span>Stream Manager</span>
            </li>
            <li class="trigger">
                <a href="studio.php">
                    <i class="fas fa-video"></i>
                    <span>Studio</span>
                </a>

            </li>
            <li class="trigger">
                <a href="playlist.php">
                    <i class="fas fa-video"></i>
                    <span>Playlist</span>
                </a>

            </li>
            <li class="trigger">
                <i class="fas fa-signal"></i>
                <span>Insights</span>
            </li>

            <li class="trigger">
                <svg viewBox="0 0 24 24" preserveAspectRatio="xMidYMid meet" focusable="false"
                     class="style-scope yt-icon" style="display: block; width: 100%; height: 100%;color: #fff;">
                    <g class="style-scope yt-icon">
                        <path
                            d="M18.7 8.7H5.3V7h13.4v1.7zm-1.7-5H7v1.6h10V3.7zm3.3 8.3v6.7c0 1-.7 1.6-1.6 1.6H5.3c-1 0-1.6-.7-1.6-1.6V12c0-1 .7-1.7 1.6-1.7h13.4c1 0 1.6.8 1.6 1.7zm-5 3.3l-5-2.7V18l5-2.7z"
                            class="style-scope yt-icon"></path>
                    </g>
                </svg>
                <span>
                        Community
                    </span>
            </li>

            <li class="trigger">
                <i class="fas fa-fire"></i>
                <span>Content</span>
            </li>

            <li class="trigger">
                <i class="fas fa-cog"></i>
                <span>Preference</span>
            </li>

            <li class="trigger">
                <svg viewBox="0 0 28 28" preserveAspectRatio="xMidYMid meet" focusable="false"
                     class="style-scope yt-icon" style="display: block; width: 100%; height: 100%;">
                    <g class="style-scope yt-icon">
                        <path
                            d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4zM14 13h-3v3H9v-3H6v-2h3V8h2v3h3v2z"
                            class="style-scope yt-icon"></path>
                    </g>
                </svg>
                <span>Streaming Tools</span>
            </li>

            <li class="trigger">
                <i class="fas fa-puzzle-piece"></i>
                <span>Extensions</span>
            </li>

    </div>

    <div class="container">
        <!-- Modal HTML embedded directly into document -->
        <div id="ex1" class="modal">
            <h4 class="bold">
                Edit Stream Info
            </h4>
            <form action="">
                <div>
                    <label for="">Title</label>
                    <textarea placeholder="Title">

                </textarea>
                </div>
                <div>
                    <label for="">Go Live Notification</label>
                    <textarea placeholder="Go Live Notification">

                </textarea>
                </div>
                <div>
                    <label for="">Category</label>
                    <input placeholder="Category">

                    </input>
                </div>
                <div>
                    <label for="">Tags</label>
                    <input placeholder="Tags">

                    </input>
                </div>
            </form>
            <div class="modalBtn">
                <a href="#" rel="modal:close" class="button Mclose">Close</a>
                <button class="button save">Save</button>
            </div>
        </div>

        <div class="wrapper">
            <section class="portal">
                <?php

                if(isset($_SESSION['error'])){
                    echo "
                                              <div class='alert alert-danger text-center'>
                                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                                <p>".$_SESSION['error']."</p> 
                                              </div>
                                            ";
                    unset($_SESSION['error']);
                }

                if(isset($_SESSION['success'])){
                    echo "
                                              <div class='alert alert-success text-center'>
                                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                                <p>".$_SESSION['success']."</p> 
                                              </div>
                                            ";
                    unset($_SESSION['success']);
                }
                ?>
            </section>
        </div>

        <?php
         $user=$_SESSION['uid'];
        $que = mysqli_query($con, "SELECT * FROM playlist WHERE user=$user") or die(mysqli_error());
        while($rw = mysqli_fetch_array($que)){
            $pid=$rw['play_id'];
            $nm=$rw['playlist_name'];
        ?>


        <section class="streamManager">
            <div class="heading">
                <h2>
                    <?php
                    echo $nm
                    ?>
                </h2>
            </div>

            <div class="playList">
                <?php

                $query = mysqli_query($con, "SELECT * FROM videos WHERE playlist=$pid") or die(mysqli_error());
                while($fetch = mysqli_fetch_array($query)){
                    $cat=$fetch['category'];
                    $vid=$fetch['vid_id'];
                    ?>
                    <?php
                    echo"
                            <a href=\"player.php?id=$vid\">"
                    ?>

                    <div>

                        <div class="boxImg">
                            <video controls width='300px' height='150px'>
                                <source src="videos/<?php echo $fetch['video']?>">
                            </video>
                        </div>
                        <div class="details">
                            <div class="profile-pic">
                                <img src="./assets/images/dummy.jpg" alt="">
                            </div>
                            <div class="video-details">
                                <div class="title">
                                    <?php
                                    echo $fetch['vid_name']
                                    ?>
                                </div>
                                <div class="channel">
                                    <?php
                                    $user=$fetch['user'];
                                    $sql="SELECT * FROM user WHERE user_id='$user'";
                                    $que=mysqli_query($con,$sql);
                                    $row=mysqli_fetch_array($que);
                                    echo $row['uname'];
                                    ?>
                                </div>
                                <div class="views">
                                    <p>17k views </p>
                                    <span class="uploaded"><?php
                                        $fetch['date']
                                        ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>

                    <?php
                }
                ?>
            </div>
        </section>
        <?php
        }
        ?>

    </div>




</section>


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
<!-- jQuery Modal -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
<script>
    var dd_main = document.querySelector(".dd_main");

    dd_main.addEventListener("click", function () {
        this.classList.toggle("active");
    })
</script>
</body>

</html>

<!-- Logout Modal-->
<div class="modal fade" id="logout" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <form action="action.php" method="post">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-primary" type="submit" name="logout">Logout</button>
                </form>

            </div>
        </div>
    </div>
</div>
