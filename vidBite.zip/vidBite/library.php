<?php
session_start();
include "db.php";
include "includes/header.php";
include "includes/navbar.php";
?>

    <!-- content section -->
    <section class="wrapper">

        <div class="playRow">
            <div class="heading">
                <h2>History</h2>
            </div>
            <div class="playList">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Save Videos</h2>
            </div>
            <div class="playList subs">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Liked Videos</h2>
            </div>
            <div class="playList">
                <?php
                $user=$_SESSION['uid'];
                $sql="SELECT * FROM up WHERE user=$user";
                $query=mysqli_query($con,$sql);
                while ($row=mysqli_fetch_array($query)){
                    $vid=$row['video'];
                ?>
                    <?php
                    $ql="SELECT * FROM videos WHERE vid_id=$vid";
                    $run=mysqli_query($con,$ql);
                    $fetch=mysqli_fetch_array($run);
                    echo"
                            <a href=\"view.php?id=$vid\">"
                    ?>

                    <div>

                        <div class="boxImg">
                            <video controls width='300px' height='150px'>
                                <source src="videos/<?php echo $fetch['video']?>">
                            </video>
                        </div>
                        <div class="details">
                            <div class="profile-pic">
                                <img src="./assets/images/dummy.jpg" alt="">
                            </div>
                            <div class="video-details">
                                <div class="title">
                                    <?php
                                    echo $fetch['vid_name']
                                    ?>
                                </div>
                                <div class="channel">
                                    <?php
                                    $user=$fetch['user'];
                                    $sql="SELECT * FROM user WHERE user_id='$user'";
                                    $que=mysqli_query($con,$sql);
                                    $row=mysqli_fetch_array($que);
                                    echo $row['uname'];
                                    ?>
                                </div>
                                <div class="views">
                                    <p>17k views </p>
                                    <span class="uploaded"><?php
                                        $fetch['date']
                                        ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>

                    <?php
                }

                ?>

            </div>
        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Watch Later</h2>
            </div>
            <div class="playList">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php
include "includes/footer.php";
