<?php
include "includes/header.php";
include "includes/navbar.php";
?>

    <!-- content section -->
    <section class="wrapper">

        <div class="playRow">
            <div class="heading">
                <h2>History</h2>
            </div>
            <div class="playList">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Save Videos</h2>
            </div>
            <div class="playList subs">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                        <a class="dots" href="#ex1" rel="modal:open">
                            <i class="fas fa-ellipsis-v"></i>
                        </a>
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Liked Videos</h2>
            </div>
            <div class="playList">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="playRow mt-5">
            <div class="heading">
                <h2>Watch Later</h2>
            </div>
            <div class="playList">
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum
                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="boxImg">
                        <img src="./assets/images/./avenger.jpg" alt="">
                    </div>
                    <div class="details">
                        <div class="profile-pic">
                            <img src="./assets/images/dummy.jpg" alt="">
                        </div>
                        <div class="video-details">
                            <div class="title">Lorem Ipsum Lorem Ipsum Lorem Ipsum

                            </div>
                            <div class="channel">New Channel</div>
                            <div class="views">
                                <p>17k views </p>
                                <span class="uploaded">2days ago</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php
include "includes/footer.php";
