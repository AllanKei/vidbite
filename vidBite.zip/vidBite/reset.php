<?php

session_start();
//Include required PHPMailer files
require 'phpmailer/includes/PHPMailer.php';
require 'phpmailer/includes/SMTP.php';
require 'phpmailer/includes/Exception.php';

//Define name spaces
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

include 'db.php';
//reset password
if (isset($_POST['reset'])) {
    $email = $_POST['email'];


    if (empty($email)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: forgot.php');

    } else {

        //existing email address in our database
        $sql = "SELECT * FROM user WHERE email = '$email' LIMIT 1";
        $check_query = mysqli_query($con, $sql);
        $count_email = mysqli_num_rows($check_query);
        $row = mysqli_fetch_array($check_query);
        $user = $row['user_id'];
        $type = $row['type'];
        if ($count_email > 0) {
            if ($type == 1) {

                //generate code
                $set = '123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $code = substr(str_shuffle($set), 0, 15);

                $sq = "UPDATE user SET reset_code = '$code' WHERE email = '$email'" or die(mysqli_error());
                $query = mysqli_query($con, $sq);

                if ($query) {

                    $message = "
                        <h2>Password Reset</h2>
                        <p>Your Account:</p>
                        <p>Email: " . $email . "</p>
                        <p>Please click the link below to reset your password.</p>
                        <a href='http://localhost/shoe/password_reset.php?code=" . $code . "&user=" . $user . "'>Reset Password</a>
                    ";


                    //Create instance of PHPMailer
                    $mail = new PHPMailer();
                    //Set mailer to use smtp
                    $mail->isSMTP();
                    //Define smtp host
                    $mail->Host = "smtp.gmail.com";
                    //Enable smtp authentication
                    $mail->SMTPAuth = true;
                    //Set smtp encryption type (ssl/tls)
                    $mail->SMTPSecure = "tls";
                    //Port to connect smtp
                    $mail->Port = "587";
                    //Set gmail username
                    $mail->Username = "keiyoh1234@gmail.com";
                    //Set gmail password
                    $mail->Password = "keiyo2017";
                    //Email subject
                    $mail->Subject = "ShoeParadise Password Reset";
                    //Set sender email
                    $mail->setFrom('keiyoh1234@gmail.com');
                    //Enable HTML
                    $mail->isHTML(true);
                    //Email body
                    $mail->Body = $message;
                    //Add recipient
                    $mail->addAddress($email);
                    //Finally send email
                    if ($mail->send()) {
                        $_SESSION['success'] = 'Password reset link sent.Check your email.';
                        header('location: forgot.php');
                        exit;
                    } else {
                        $_SESSION['error'] = 'Message could not be sent. Mailer Error: ' . $mail->ErrorInfo;
                        header('location: forgot.php');
                    }
                    //Closing smtp connection
                    $mail->smtpClose();


                }
            } else {
                $_SESSION['error'] = 'Please activate your account first';
                header('location:forgot.php');
            }

        } else {

            $_SESSION['error'] = 'Email does not exists in our records, <a href="signup.php">Signup</a> instead';
            header('location:forgot.php');

        }
    }

}