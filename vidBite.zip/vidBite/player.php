<?php
session_start();
include "db.php";
include "includes/header.php";
include "includes/navbar.php";
$vid = $_GET['id'];
$user=$_SESSION['uid'];
?>



    <!-- content section -->
    <section class="wrapper">

        <div class="playRow">
            <div class="heading">
                <h2>Recommended For You</h2>
            </div>
            <div class="playList2">
                <?php
                $n=0;
                $n++;
                $query = mysqli_query($con, "SELECT * FROM videos WHERE vid_id=$vid") or die(mysqli_error());
                while($fetch = mysqli_fetch_array($query)){
                    $cat=$fetch['category'];
                    ?>
                    <div>
                        <div class="boxImg2">
                            <video controls width='100%' height='500px'>
                                <source src="videos/<?php echo $fetch['video']?>">
                            </video>
                        </div>
                        <div class="details">
                            <div class="profile-pic">
                                <img src="./assets/images/dummy.jpg" alt="">
                            </div>
                            <div class="video-details">
                                <div class="title">
                                    <?php
                                    echo $fetch['vid_name']
                                    ?>
                                </div>
                                <div class="channel">
                                    <?php
                                    $user=$fetch['user'];
                                    $sq="SELECT * FROM user WHERE user_id='$user' ";
                                    $q=mysqli_query($con,$sq);
                                    $rq=mysqli_fetch_array($q);
                                    $uname=$rq['uname'];

                                    echo "
                                            <a href=\"user.php?id=$user\">
                                            $uname Channel
                                            </a>
                                            "
                                    ?>
                                </div>
                                <div class="views">
                                    <p>
                                        <?php
                                        $qry = "SELECT COUNT(*) AS count_item FROM views WHERE video=$vid";
                                        $query_run = mysqli_query($con,$qry);
                                        $wr = mysqli_fetch_array($query_run);
                                        $count = $wr["count_item"];

                                        echo ''.$count.' views';
                                        ?>
                                    </p>
                                    <span class="uploaded"><?php
                                        $fetch['date']
                                        ?></span>
                                </div>
                                <div class="icon">
                                    <?php
                                    $qry = "SELECT COUNT(*) AS count_item FROM up WHERE video=$vid";
                                    $query_run = mysqli_query($con,$qry);
                                    $wr = mysqli_fetch_array($query_run);
                                    $count = $wr["count_item"];

                                    ?>
                                    <form action="action.php" method="post">
                                        <input type="hidden" name="user" value="<?php echo $_SESSION['uid']?>">
                                        <input type="hidden" name="vid" value="<?php echo $fetch['vid_id']?>">
                                        <button type="submit" name="like">
                                            <i class="fas fa-thumbs-up"></i> <?php echo $count?>
                                        </button>
                                        <?php
                                        $qry = "SELECT COUNT(*) AS count_item FROM down WHERE video=$vid";
                                        $query_run = mysqli_query($con,$qry);
                                        $wr = mysqli_fetch_array($query_run);
                                        $count = $wr["count_item"];

                                        ?>
                                        <button type="submit" name="unlike">
                                            <i class="fas fa-thumbs-down"></i><?php echo $count?>
                                        </button>
                                    </form>
                                </div>
                                <div class="comments">
                                    <form action="action.php" method="post">
                                        <input type="hidden" name="video" value="<?php echo $fetch['vid_id']?>">
                                        <input type="hidden" name="user" value="<?php echo $_SESSION['uid']?>">
                                        <input type="text" name="comment" placeholder="Enter your comment...">
                                        <input type="submit" name="comm" value="send">
                                    </form>
                                    <h6>Comments</h6>
                                    <div class="display-chat">
                                        <?php
                                        $sql="SELECT * FROM `comment` WHERE video=$vid";

                                        $que = mysqli_query($con,$sql);
                                        if(mysqli_num_rows($que)>0)
                                        {
                                            while($row= mysqli_fetch_array($que))

                                            {
                                                $mes=$row['message'];
                                                $us=$row['user'];
                                                $so="SELECT * FROM user WHERE user_id=$us";
                                                $quer = mysqli_query($con, $so);
                                                $rw = mysqli_fetch_array($quer);
                                                $name=$rw['uname'];
                                                ?>
                                                <div class="message">
                                                    <p>
                                                        <?php
                                                        echo"
                                                            <a href=\"user.php?id=$us\">
                                                               <span>$name</span> 
                                                            </a>";
                                                        ?><br>
                                                        <?php echo $mes ?>
                                                    </p>
                                                </div>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                            <div class="message">
                                                <p>
                                                    No previous comments.
                                                </p>
                                            </div>
                                            <?php
                                        }
                                        ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <form action="action.php" method="post">
                                <button type="submit" name="subscribe" class="btn btn-secondary">
                                    <i class="fas fa-bell"></i>Subscribe
                                </button>
                            </form>

                        </div>
                        <div>
                            <form action="action.php" method="post">
                                <button type="submit" name="save" class="btn btn-secondary">
                                    <i class="fas fa-bell"></i>Save
                                </button>
                            </form>

                        </div>
                        <div>
                            <form action="action.php" method="post">
                                <button type="submit" name="watch" class="btn btn-secondary">
                                    <i class="fas fa-bell"></i>Watch later
                                </button>
                            </form>

                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>

    </section>

<?php
include "includes/footer.php";

