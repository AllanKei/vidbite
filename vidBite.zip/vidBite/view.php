<?php

session_start();
include "db.php";
$vid = $_GET['id'];
$user = $_SESSION['uid'];
//existing user view
$sq = "SELECT view_id FROM views WHERE user = '$user' AND video ='$vid' LIMIT 1";
$check_query = mysqli_query($con, $sq);
$count_user = mysqli_num_rows($check_query);
if ($count_user > 0) {
    header('location:player.php'."?id=$vid");
    exit();
} else {
    $date=date('Y-m-d H:i:s');
    $sql = "INSERT INTO views (`view_id`, `user`,`video`,`timestamp`) VALUES(NULL,'$user','$vid','$date') ";
    $quer = mysqli_query($con, $sql);
    if ($quer) {
        header('location:player.php' . "?id=$vid");
    } else {
        header('location:player.php' . "?id=$vid");
    }
}
