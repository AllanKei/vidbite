<?php
session_start();
include "db.php";
include "includes/header.php";
include "includes/navbar.php";
$sql="SELECT * FROM `chat`";

$query = mysqli_query($con,$sql);
?>
<style>
    h2{
        color:white;
    }
    label{
        color:white;
    }
    span{
        color:#673ab7;
        font-weight:bold;
    }
    .container {
        margin-top: 3%;
        width: 60%;
        background-color: #26262b9e;
        padding-right:10%;
        padding-left:10%;
    }
    .btn-primary {
        background-color: #673AB7;
    }
    .display-chat{
        height:300px;
        background-color:#d69de0;
        margin-bottom:4%;
        overflow:auto;
        padding:15px;
    }
    .message{
        background-color: #c616e469;
        color: white;
        border-radius: 5px;
        padding: 5px;
        margin-bottom: 3%;
    }
</style>
<section class="wrapper">
    <div class="container">
        <center><h2>Chats</span></h2>
        </center></br>
        <div class="display-chat">
            <?php
            if(mysqli_num_rows($query)>0)
            {
                while($row= mysqli_fetch_assoc($query))
                    $us=$row['users'];
                $s="SELECT * FROM chat_session WHERE ses_id=$us";
                $query = mysqli_query($con, $s);
                $r = mysqli_fetch_array($query);
                $r1=$r['fuser'];
                $r2=$r['suser'];

                if ($r1==$_SESSION['uid']){
                    $so="SELECT * FROM user WHERE user_id=$r2";
                    $quer = mysqli_query($con, $so);
                    $rw = mysqli_fetch_array($quer);
                    $name=$rw['uname'];
                }
                else{
                    if ($r2==$_SESSION['uid']){
                        $sop="SELECT * FROM user WHERE user_id=$r1";
                        $queri = mysqli_query($con, $sop);
                        $rws = mysqli_fetch_array($queri);
                        $name=$rws['uname'];
                    }
                }

                {
                    ?>
                    <div class="message">
                        <p>
                            <?php
                            echo"
                            <a href=\"chat.php?id=$us\">
                                $name
                            </a>";
                            ?>


                        </p>
                    </div>
                    <?php
                }
            }
            else
            {
                ?>
                <div class="message">
                    <p>
                        No previous chat available.
                    </p>
                </div>
                <?php
            }
            ?>

        </div>
    </div>
</section>


</body>
</html>