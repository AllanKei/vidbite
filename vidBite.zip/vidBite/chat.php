<?php
session_start();
include "db.php";
include "includes/header.php";
include "includes/navbar.php";
$user=$_SESSION['uid'];
$id = $_GET['id'];
?>
<style>
    h2{
        color:white;
    }
    label{
        color:white;
    }
    span{
        color:#673ab7;
        font-weight:bold;
    }
    .container {
        margin-top: 3%;
        width: 60%;
        background-color: #26262b9e;
        padding-right:10%;
        padding-left:10%;
    }
    .btn-primary {
        background-color: #673AB7;
    }
    .display-chat{
        height:300px;
        background-color:#d69de0;
        margin-bottom:4%;
        overflow:auto;
        padding:15px;
    }
    .message{
        background-color: #c616e469;
        color: white;
        border-radius: 5px;
        padding: 5px;
        margin-bottom: 3%;
    }
</style>
<?php
$s="SELECT * FROM chat_session WHERE ses_id=$id";
$query = mysqli_query($con, $s);
$r = mysqli_fetch_array($query);
$r1=$r['fuser'];
$r2=$r['suser'];

if ($r1==$_SESSION['uid']){
    $so="SELECT * FROM user WHERE user_id=$r2";
    $quer = mysqli_query($con, $so);
    $rw = mysqli_fetch_array($quer);
    $rid=$rw['user_id'];
    $name=$rw['uname'];
}
else{
    if ($r2==$_SESSION['uid']){
        $sop="SELECT * FROM user WHERE user_id=$r1";
        $queri = mysqli_query($con, $sop);
        $rws = mysqli_fetch_array($queri);
        $rid=$rws['user_id'];
        $name=$rws['uname'];
    }
}

?>
<section class="wrapper">
    <div class="container">
    <center><h2> <span style="color:#dd7ff3;"><?php echo $name ?> !</span></h2>
    </center></br>
    <div class="display-chat">
        <?php
        $sql="SELECT * FROM `chat` WHERE users=$id";

        $query = mysqli_query($con,$sql);
        if(mysqli_num_rows($query)>0)
        {
            while($row= mysqli_fetch_assoc($query))
            {
                ?>
                <div class="message">
                    <p>
                        <?php echo $row['message']; ?>
                    </p>
                </div>
                <?php
            }
        }
        else
        {
            ?>
            <div class="message">
                <p>
                    No previous chat available.
                </p>
            </div>
            <?php
        }
        ?>

    </div>
    <form class="form-horizontal" method="post" action="action.php">
        <div class="form-group">
            <input  type="hidden" name="sender" value="<?php echo $user?>">
            <input  type="hidden" name="receiver" value="<?php echo $rid?>">
            <input  type="hidden" name="users" value="<?php echo $id?>">
            <div class="col-sm-10">
                <textarea name="msg" class="form-control" placeholder="Type your message here..."></textarea>
            </div>

            <div class="col-sm-2">
                <button type="submit" name="message" class="btn btn-primary">Send</button>
            </div>

        </div>
    </form>
</div>
</section>

</body>
</html>